﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class UserController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<UserController> _logger;
        private readonly IWebHostEnvironment _env;

        public UserController(IConfiguration configuration, ILogger<UserController> logger, IWebHostEnvironment env)
        {
            _configuration = configuration;
            _logger = logger;
            _env = env;
        }

        private string GetConnectionString() => _configuration.GetConnectionString("DefaultConnection");

        // ✅ List all users
        public IActionResult UserList()
        {
            var users = new List<UserModel>();
            try
            {
                using var conn = new SqlConnection(GetConnectionString());
                using var cmd = new SqlCommand("PR_User_GetAll", conn) { CommandType = CommandType.StoredProcedure };
                conn.Open();
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    users.Add(new UserModel
                    {
                        id = Convert.ToInt32(reader["id"]),
                        name = reader["name"].ToString(),
                        profileImgSrc = reader["profileImgSrc"].ToString()
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading users");
                TempData["ErrorMessage"] = "Unable to load users.";
            }
            return View(users);
        }

        // ✅ Get user for Add/Edit
        public IActionResult UserAddEdit(int? id)
        {
            var user = new UserModel();
            if (id.HasValue && id.Value > 0)
            {
                try
                {
                    using var conn = new SqlConnection(GetConnectionString());
                    using var cmd = new SqlCommand("PR_User_GetById", conn) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.AddWithValue("@Id", id.Value);
                    conn.Open();
                    using var reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        user.id = Convert.ToInt32(reader["id"]);
                        user.name = reader["name"].ToString();
                        user.profileImgSrc = reader["profileImgSrc"].ToString();
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error loading user");
                    TempData["ErrorMessage"] = "Unable to load user.";
                }
            }
            return View(user);
        }

        // ✅ Insert or Update user (no async here)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(UserModel user)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    // Log validation errors
                    foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                    {
                        _logger.LogWarning("Validation Error: {Error}", error.ErrorMessage);
                    }
                    return View("UserAddEdit", user);
                }

                // Handle file upload
                if (user.profileImg != null && user.profileImg.Length > 0)
                {
                    var uploadsFolder = Path.Combine(_env.WebRootPath, "images", "Profile");
                    Directory.CreateDirectory(uploadsFolder);

                    var ext = Path.GetExtension(user.profileImg.FileName);
                    var uniqueFileName = $"{Guid.NewGuid()}{ext}";
                    var physicalPath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var stream = new FileStream(physicalPath, FileMode.Create))
                    {
                        user.profileImg.CopyTo(stream);
                    }

                    // Delete old file
                    if (!string.IsNullOrEmpty(user.profileImgSrc))
                    {
                        var oldFile = Path.Combine(_env.WebRootPath, user.profileImgSrc.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
                        if (System.IO.File.Exists(oldFile))
                        {
                            System.IO.File.Delete(oldFile);
                        }
                    }

                    user.profileImgSrc = $"/images/Profile/{uniqueFileName}";
                }

                using var conn = new SqlConnection(GetConnectionString());
                conn.Open();

                if (user.id == 0)
                {
                    using var cmd = new SqlCommand("PR_User_Insert", conn) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.AddWithValue("@Name", user.name);
                    cmd.Parameters.AddWithValue("@ProfileImgSrc", (object?)user.profileImgSrc ?? DBNull.Value);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    using var cmd = new SqlCommand("PR_User_Update", conn) { CommandType = CommandType.StoredProcedure };
                    cmd.Parameters.AddWithValue("@Id", user.id);
                    cmd.Parameters.AddWithValue("@Name", user.name);
                    cmd.Parameters.AddWithValue("@ProfileImgSrc", (object?)user.profileImgSrc ?? DBNull.Value);
                    cmd.ExecuteNonQuery();
                }

                TempData["SuccessMessage"] = "User saved successfully!";
                return RedirectToAction("UserList");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving user");
                ModelState.AddModelError("", "Error while saving user: " + ex.Message);
                return View("UserAddEdit", user);
            }
        }


        // ✅ Delete user
        public IActionResult DeleteUser(int id)
        {
            try
            {
                if (id > 0)
                {
                    string? profileImgSrc = null;

                    // Get image before deleting
                    using (var conn = new SqlConnection(GetConnectionString()))
                    using (var cmd = new SqlCommand("PR_User_GetById", conn) { CommandType = CommandType.StoredProcedure })
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        conn.Open();
                        using var reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            profileImgSrc = reader["profileImgSrc"].ToString();
                        }
                    }

                    // Delete file
                    if (!string.IsNullOrEmpty(profileImgSrc))
                    {
                        var filePath = Path.Combine(_env.WebRootPath, profileImgSrc.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
                        if (System.IO.File.Exists(filePath))
                        {
                            System.IO.File.Delete(filePath);
                        }
                    }

                    // Delete from DB
                    using (var conn = new SqlConnection(GetConnectionString()))
                    using (var cmd = new SqlCommand("PR_User_Delete", conn) { CommandType = CommandType.StoredProcedure })
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }

                    TempData["SuccessMessage"] = "User deleted successfully!";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting user");
                TempData["ErrorMessage"] = "Error while deleting user.";
            }

            return RedirectToAction("UserList");
        }
    }
}
