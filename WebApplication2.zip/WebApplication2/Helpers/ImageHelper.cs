﻿namespace WebApplication2.Helpers;

using System;
using System.IO;
using Microsoft.AspNetCore.Http;

public class ImageHelper
{
    public static string SaveImage(IFormFile file, string folderName)
    {
        string wwwRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
        string folderPath = Path.Combine(wwwRootPath, folderName);

        if (!Directory.Exists(folderPath))
            Directory.CreateDirectory(folderPath);

        string fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
        string filePath = Path.Combine(folderPath, fileName);

        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            file.CopyTo(stream);
        }

        // ✅ Return relative path for browser
        return "/" + folderName + "/" + fileName;
    }


    public static string DeleteFileFromUrl(string filePath)
    {
        if (string.IsNullOrWhiteSpace(filePath))
            return "File URL is required.";

        var finalFilePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", filePath.TrimStart('/'));

        if (!System.IO.File.Exists(finalFilePath))
            return "File not found.";

        try
        {
            System.IO.File.Delete(finalFilePath);
            return "File deleted successfully.";
        }
        catch
        {
            throw;
        }
    }
}
