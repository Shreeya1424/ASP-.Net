﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace WebApplication2.Models
{
    //public class UserModel
    //{
    //    [Key]
    //    public int id { get; set; }

    //    [Required(ErrorMessage = "Name is required")]
    //    public string name { get; set; }

    //    // This stores the public URL /Profile/<guid>.jpg that we keep in DB
    //    public string profileImgSrc { get; set; }

    //    // This property is only used for binding file uploads from the view.
    //    // It should NOT be mapped to the database.
    //    [NotMapped]
    //    public IFormFile profileImg { get; set; }
    //}
    public class UserModel
    {
        public int id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string name { get; set; }

        public string? profileImgSrc { get; set; }

        [Display(Name = "Upload Profile Image")]
        public IFormFile? profileImg { get; set; }
    }

}
